import logging
import sys
import warnings
from contextlib import contextmanager

from . import _native as lib

LOGGER = logging.getLogger(__name__)

LineNo = lib.LineNo
ProfilerImplementation = lib.ProfilerImplementation
SignalTimer = lib.SignalTimer


def configure(
    app_name=None,
    application_name=None,
    server_address="http://localhost:4040",
    basic_auth_username="",
    basic_auth_password="",
    enable_logging=False,
    sample_rate=100,
    oncpu=True,
    native=None,
    gil_only=True,
    report_pid=False,
    report_thread_id=False,
    report_thread_name=False,
    tags=None,
    tenant_id="",
    http_headers=None,
    line_no=LineNo.LastInstruction,
    upload_interval=10,
    mem_enabled=False,
    mem_max_nframe=128,
    mem_heap_sample_size=512 * 1024,
    mem_enable_mem_domain=True,
    cpu_enabled=True,
    cpu_implementation=ProfilerImplementation.PySpy,
    signal_timer=SignalTimer.CTimer if sys.platform == "linux" else SignalTimer.ITimer,
):
    if app_name is not None:
        warnings.warn(
            "app_name is deprecated, use application_name", DeprecationWarning
        )
        application_name = app_name

    if native is not None:
        warnings.warn("native is deprecated and not supported", DeprecationWarning)

    LOGGER.disabled = not enable_logging
    if enable_logging:
        log_level = LOGGER.getEffectiveLevel()
        lib.initialize_logging(log_level)

    return lib.initialize_agent(
        application_name,
        server_address,
        basic_auth_username,
        basic_auth_password,
        sample_rate,
        oncpu,
        gil_only,
        report_pid,
        report_thread_id,
        report_thread_name,
        runtime_name(),
        runtime_version(),
        tags or {},
        tenant_id or "",
        http_headers or {},
        line_no,
        upload_interval,
        mem_enabled,
        mem_max_nframe,
        mem_heap_sample_size,
        mem_enable_mem_domain,
        cpu_enabled,
        cpu_implementation,
        signal_timer,
    )


def configure_experimental_stack_profiler(
    max_nframe=128,
    max_threads=25,
    adaptive_sampling=True,
    adaptive_target_overhead=0.01,
    adaptive_max_interval_us=100000,
    adaptive_baseline=0.0,
    adaptive_p_stable_window_s=600,
    adaptive_p_stable_percentile=95.0,
    cpu_timer_enabled=True,
    cpu_timer_interval_ms=10,
):
    """Set the options of the stack CPU profiler, for the whole process.

    Only the first call takes effect. A later call is refused and returns
    False, including after shutdown(), and so is any call made once a
    configure() with cpu_implementation=ProfilerImplementation.Stack has
    started the profiler.

    The profiler reads the sampled memory with memcpy under its own
    SIGSEGV/SIGBUS handlers, and configure() returns False when it cannot
    install them. Enable faulthandler before configure(): the handlers chain
    to the faulthandler that is already installed, but a later
    faulthandler.enable() replaces them and the profiler stops sampling.

    max_threads caps how many threads one sampling cycle covers; past the cap
    the sampler picks a uniform random subset. 0 means no cap.

    cpu_timer_enabled uses per-thread CPU timers on Linux CPython 3.12+.
    Older Python versions and macOS use the wall sampler even when this
    option is enabled. With CPU timers active, the profiler cannot restart
    after shutdown() or in a fork child, and configure() returns False.

    adaptive_sampling moves the sampling interval between 100us and
    adaptive_max_interval_us to keep the sampler near adaptive_target_overhead,
    a fraction of the process CPU time. adaptive_baseline is an overhead floor
    in core-percent units (1 = 0.01 core, 0 disables the floor), and
    adaptive_p_stable_percentile is a percentage between 0 and 100 of the app
    CPU seen over the last adaptive_p_stable_window_s seconds.
    """
    return lib.configure_experimental_stack_profiler(
        max_nframe,
        max_threads,
        adaptive_sampling,
        adaptive_target_overhead,
        adaptive_max_interval_us,
        adaptive_baseline,
        adaptive_p_stable_window_s,
        adaptive_p_stable_percentile,
        cpu_timer_enabled,
        cpu_timer_interval_ms,
    )


def shutdown():
    drop = lib.drop_agent()

    if drop:
        LOGGER.info("Pyroscope Agent successfully shutdown")
    else:
        LOGGER.warning("Pyroscope Agent shutdown failed")
    return drop


def add_thread_tag(key, value):
    return lib.add_thread_tag(key, value)


def remove_thread_tag(key, value):
    return lib.remove_thread_tag(key, value)


def runtime_name():
    return sys.implementation.name


def runtime_version():
    vinfo = sys.implementation.version
    if vinfo.releaselevel == "final" and not vinfo.serial:
        vinfo = vinfo[:3]
    return ".".join(map(str, vinfo))


@contextmanager
def tag_wrapper(tags):
    for key, value in tags.items():
        lib.add_thread_tag(key, value)
    try:
        yield
    finally:
        for key, value in tags.items():
            lib.remove_thread_tag(key, value)


def stop():
    warnings.warn("deprecated, no longer applicable", DeprecationWarning)


def change_name(name):
    warnings.warn("deprecated, no longer applicable", DeprecationWarning)


def tag(tags):
    warnings.warn("deprecated, use tag_wrapper function", DeprecationWarning)


def remove_tags(*keys):
    warnings.warn("deprecated, no longer applicable", DeprecationWarning)


def build_summary():
    warnings.warn("deprecated, no longer applicable", DeprecationWarning)


def test_logger():
    warnings.warn("deprecated, no longer applicable", DeprecationWarning)


def _install_stack_threads(threading, register, unregister):
    Thread = threading.Thread
    orig_set_native_id = Thread._set_native_id

    def _set_native_id(self):
        orig_set_native_id(self)
        if self.ident is not None and self.native_id is not None:
            register(self.ident, self.native_id)

    if sys.version_info >= (3, 11):
        # _delete is called by threads already running when the hook is installed,
        # and by new threads even if their run method raises.
        orig_delete = Thread._delete

        def _delete(self):
            try:
                orig_delete(self)
            finally:
                if self.ident is not None:
                    unregister(self.ident)

        # Install the exit hook first so a thread registered during installation
        # cannot exit before its cleanup hook is available.
        Thread._delete = _delete
        Thread._set_native_id = _set_native_id
    else:
        # Python 3.10 removes the thread from _active inside _bootstrap_inner
        # without calling _delete.
        orig_bootstrap_inner = Thread._bootstrap_inner

        def _bootstrap_inner(self, *args, **kwargs):
            orig_bootstrap_inner(self, *args, **kwargs)
            if self.ident is not None:
                unregister(self.ident)

        Thread._set_native_id = _set_native_id
        Thread._bootstrap_inner = _bootstrap_inner

    _register_stack_threads(threading, register)


def _register_stack_threads(threading, register):
    current_id = threading.get_ident()
    for tid, thread in list(threading._active.items()):
        # Older Python versions retain the parent's Thread.native_id after fork.
        native_id = (
            threading.get_native_id()
            if tid == current_id
            else getattr(thread, "native_id", None) or tid
        )
        register(tid, native_id)

Benchmark reproduction bundle

Run the commands in benchmark-report.md. The supplied SDK wheel is unchanged.
The generic run_benchmark.py entry point defaults only its metadata label to
benchmark; sampling, process layout, warmup, measurement, seed and CPU sets
match the recorded run. All profilers use gil_only=False and Signal uses CTimer.
Runtime-context contains the pinned base Dockerfile, Django app and exact SDK
wheel. Source commits and expected hashes are recorded in source.json.
The load generator binary is supplied; loadgen.go is included for inspection.

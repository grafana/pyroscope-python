Extract this ZIP, then open benchmark-report.md.
The report contains a concise summary and collapsible methodology/results.
Its reproduction section explains how to unpack and use benchmark-reproduction.tar.gz.
